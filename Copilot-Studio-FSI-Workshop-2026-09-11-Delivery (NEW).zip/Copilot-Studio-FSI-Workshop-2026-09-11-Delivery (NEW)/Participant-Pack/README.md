# Advisor Meeting Prep — Participant Pack

**Manulife workshop | 11 September 2026 | Fictional Contoso Assurance training only**

1. Extract the entire ZIP.
2. Open [START-HERE.html](START-HERE.html) in your browser. No installation is required for the pack.
3. Set your assigned team key and follow the participant lab.
4. Download the three knowledge DOCX files from the portal and upload one to each assigned specialist.
5. Use the PDF/Word handouts when preferred. The participant handout contains all seven copy-and-paste prompts in its appendix.

The portal is offline; Copilot Studio requires internet, an approved environment, credits, and an account that can publish and invoke specialists. Trial-only Preview may not support the full exercise. No real customer data, product terms, or business writes are needed.

The local test worksheet is not an automated agent evaluation. Current feature documentation and limitations are in [Sources and Feature Notes](07-Sources-and-Feature-Notes.html). This pack is not a Copilot Studio importable solution.
