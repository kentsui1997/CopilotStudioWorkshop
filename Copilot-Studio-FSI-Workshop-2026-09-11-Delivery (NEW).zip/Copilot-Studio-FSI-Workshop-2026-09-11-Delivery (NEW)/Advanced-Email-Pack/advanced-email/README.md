# Advanced Email Exercise Assets

**Opt-in only. This exercise can send real email.** Use an approved training environment, the end user's own Outlook connection, a fixed controlled internal test recipient, and synthetic content only.

These files extend the workshop without changing the original T08 no-send expectation. Create one new Email Hub that reuses the existing three specialists. The specialist named Follow-up Drafting remains draft-only; only the new Email Hub receives the single send tool.

- [Builder prompt](prompts/00-Email-Hub-Builder.txt): optional new Hub shell, no automatic tool binding or send.
- [Email Hub full instructions](prompts/01-Email-Hub-Instructions.txt): replace the new Hub's starter text, not the original core Hub's instructions.
- [Send tool description](prompts/02-Send-Tool-Description.txt): describe the one real-mail action.
- [Outlook draft-handoff alternative](prompts/03-Outlook-Draft-Handoff-Instructions.txt): use instead when the human should click Send in Outlook. Remove/omit all send tools on that path.
- [Advanced cases](tests/cases.json): ten manually supervised cases, separate from the original 14-case core worksheet. Some can send actual messages; this is not a Copilot Studio evaluation import file.

Replace `{{TEAM}}` and `{{TEST_RECIPIENT}}` before pasting. Never enter credentials, access tokens, or real customer data into these files. A typed recipient or From address does not establish authorization or sender identity.

The standard-harness docs explicitly describe end-user/maker auth and a pre-run confirmation setting. The new-harness add/manage pages do not verify those exact toggle labels; check the supported behavior in your tenant, and prove sender identity with a second non-maker user. Chat approval alone is behavioral guidance, not a deterministic approval control.