# Tenant Preflight — Go / No-Go

**Complete on 10 September 2026 for the 11 September workshop.**

This checklist is for the instructor and tenant administrator. The core lab uses synthetic documents and no external business connectors, but still needs working Copilot Studio access, credits, publication, and connected-agent invocation.

## 1. Account and environment gates

- [ ] A tenant administrator has approved the selected development/sandbox environment for the exercise.
- [ ] A representative participant can sign in, select the correct environment, and see GitHub-harness agent creation.
- [ ] The account has maker and knowledge-upload permissions.
- [ ] The participant account can **publish a specialist agent**. A trial-only account that can use Preview is insufficient if it cannot publish.
- [ ] The participant can enable **Allow other agents to connect**.
- [ ] The participant can connect and successfully invoke a published specialist in the same environment.
- [ ] Microsoft authentication works under the tenant's permitted channel configuration.
- [ ] The facilitator's account passes the same tests; elevated admin access is not used as a substitute for participant validation.

**Stop condition:** failure to publish or connect is a hard gate for the four-agent lab. Do not tell participants to buy unrelated GitHub Copilot seats or to disable authentication. Escalate the Copilot Studio entitlement/policy issue to the tenant administrator.

## 2. Capacity and governance gates

- [ ] Copilot Credits are allocated or the approved billing arrangement is active.
- [ ] The administrator has reviewed potential consumption from **building, testing, and evaluating**, not just published use.
- [ ] Approved models and any relevant cross-region/external-model policies are confirmed.
- [ ] The natural-language builder is approved if used; current documentation labels it preview. Manual new-harness creation is the fallback.
- [ ] DLP/data policies allow knowledge upload and the rehearsed publication/connection path.
- [ ] The administrator understands the synthetic data scope and the platform's transcript/log retention.
- [ ] Optional workflow creation and execution are separately permitted if that extension will be demonstrated.
- [ ] No real Manulife customer data, internal product terms, real signatures, or confidential documents are required.

No exact credit-per-participant amount is promised: it depends on the chosen model, iteration count, and runtime. Rehearse representative tasks and monitor actual consumption. Timebox builder retries to avoid both cost and schedule drift.

## 3. Rehearsal with a participant account

1. Create a temporary, clearly prefixed GitHub-harness specialist in the approved environment.
2. Paste the supplied Client Briefing instructions and attach the Synthetic Client Snapshot DOCX.
3. Verify the source is ready; test LAB-001 in Preview.
4. Enable **… → Settings → AI & behavior → Allow other agents to connect**; save and publish.
5. Create a Hub in that same environment, attach the published specialist, and test actual delegation.
6. Complete the remaining two specialists and run T03, T05, T07, and T08.
7. If sharing specialists, repeat using a participant who is not their owner. Verify access and invocation; listing alone is insufficient.
8. Record the exact UI labels/channel steps used in this tenant. Add screenshots only from the approved synthetic rehearsal.
9. Remove or retain rehearsal artifacts according to the agreed policy; leave the instructor's finished FSI-DEMO set intact for tomorrow.

Record: rehearsal owner; environment display name; participant account tested; test date/time; publication path; pass/fail; unresolved blockers; admin contact. Do not record passwords, tokens, or keys.

## 4. Group planning

Recommended model: two participants per team, one signed-in maker owns the team's four agents, partner verifies evidence. Swap the driver without sharing credentials.

| Item | Planning rule |
|---|---|
| Team key | FSI-P01, FSI-P02, etc.; facilitator uses FSI-DEMO / FSI-LIVE |
| Core artifacts | Four agents per team |
| Knowledge uploads | Three documents per team |
| Optional artifacts | One workflow per completing team |
| Example: 16 teams | 64 participant agents, plus the facilitator's prepared sets |
| Shared specialists | Pretest ownership/sharing; do not reuse a specialist from another environment |

Ask the administrator to verify the environment's current capacity and applicable limits for the intended group size. Do not assume this planning example is a guaranteed service quota.

## 5. Delivery and room setup

- [ ] Participant ZIP sent through an approved channel, with extract-first instructions.
- [ ] Participants can open the offline portal and obtain the three DOCX uploads.
- [ ] Instructor has the full facilitator ZIP, PowerPoint, PDF backup, and runbook.
- [ ] Network allows the needed Microsoft sign-in and Copilot Studio endpoints.
- [ ] Projection resolution and zoom checked; instruction copy buttons are readable.
- [ ] Teams/pairs and prefix list assigned.
- [ ] Backup recording or screenshots come from an actual rehearsal, not an illustrative answer.
- [ ] Admin/helper contact available at the beginning of the lab.

## 6. Invitation text to send participants

> Tomorrow's lab builds four connected agents in Microsoft Copilot Studio's GitHub Copilot harness. Please use the organizer-provided account and environment, extract the participant ZIP, and open START-HERE in your browser. The pack works offline; the lab platform requires internet and tenant access. Bring a laptop. We will use only fictional Contoso Assurance profiles and products, not real Manulife customer data. Tell the organizer before the session if you cannot create and publish an agent. Do not share passwords or enter real customer information.

## 7. Final decision

- **Green:** representative participant completed knowledge upload, specialist publication, connection, and invocation. Run the full lab.
- **Amber:** only shared-specialist mode is validated. Announce the reduced build scope; use pretested shared components.
- **Red:** no new-harness access or no working connected-agent path. Use a clearly labeled guided-design/observation session rather than promising a hands-on deployment.

## 8. Separate gate for the advanced Outlook email exercise

This gate is **not needed for the no-write core**. Complete it only if choosing [T08-Advanced](09-T08-Advanced-Outlook-Send.md) instead of the Meeting Window extension:

- [ ] Real-email training has explicit environment/mailbox-owner approval and a controlled internal recipient.
- [ ] New Email Hub is separate; original Hub and three specialists are unchanged.
- [ ] Only Office 365 Outlook Send an email (V2) is attached; no booking/logging or broad HTTP/MCP send path.
- [ ] Tool uses end-user OAuth, not maker/author or shared-mailbox credentials; From/Send-as is unset.
- [ ] Fixed recipient and empty optional recipient/attachment fields are configured independently of the prompt, or an approved equivalent restriction exists.
- [ ] Cancel and edit tests prevent a send; a complete preview is followed by a separate explicit approval turn.
- [ ] Any claimed native pre-run confirmation is actually present and tested in this new-harness tenant; standard-harness documentation alone is not proof.
- [ ] Non-maker user B's approved test really appears in **B's Sent Items** and from B at the controlled recipient; maker A-only Preview is insufficient.
- [ ] No unattended live-send evaluations; unknown outcomes are not blindly retried.
- [ ] If independent approval enforcement or per-user identity cannot be established, use the documented manual-Outlook-send fallback, or keep the extension design-only.

## Primary references

- [Create new agents](https://learn.microsoft.com/en-us/microsoft-copilot-studio/agents-experience/build-new-agent)
- [Trial/publication note and builder preview](https://learn.microsoft.com/en-us/microsoft-copilot-studio/create-automation-natural-language)
- [Connected-agent prerequisites](https://learn.microsoft.com/en-us/microsoft-copilot-studio/agents-experience/add-agent-connected)
- [Authentication and connectable settings](https://learn.microsoft.com/en-us/microsoft-copilot-studio/agents-experience/settings-overview)
- [Usage-based billing](https://learn.microsoft.com/en-us/microsoft-copilot-studio/agents-experience/billing-credit-overview)

Documentation checked 10 September 2026; actual entitlement and UI availability must be validated in the workshop tenant.
