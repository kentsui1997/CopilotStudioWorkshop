# Synthetic Client Snapshot

**FICTIONAL WORKSHOP DATA — NOT MANULIFE CUSTOMER DATA**

Version 1.0 | Snapshot date: **11 September 2026** | Currency: HKD

## How to use this document

This document belongs to the fictional **Contoso Assurance** workshop scenario. All people, identifiers, policies, contact addresses, and circumstances below are invented. This is a small static training snapshot, not a live policy administration system. Do not describe a record as current, verified, or retrieved from a production database.

Use a client identifier to select exactly one record. Two records deliberately share the name Chris Lee. A name alone is insufficient for those records: ask the advisor for LAB-004 or LAB-005 before proceeding. Do not merge clients. For an unknown identifier, report that the snapshot has no matching record.

An absent fact is **not supplied**, not a negative answer. In particular, an absent health disclosure is not evidence of no pre-existing conditions. No eligibility, underwriting, claim, premium, or suitability decision is supplied here. Never invent an email address.

The reserved example.invalid addresses are non-deliverable training placeholders. No emails or invitations are to be sent in the core lab.

## Client LAB-001 — David Chan

- **Client ID:** LAB-001
- **Full name:** David Chan
- **Age stated in snapshot:** 42
- **Family context:** Married; two dependent children.
- **Existing policy reference:** LAB-POL-1001
- **Existing fictional cover:** Contoso Family Term 10.
- **Recorded life sum assured:** HKD 1,000,000.
- **Policy status recorded in snapshot:** Active.
- **Planned advisor review date:** 1 October 2026. This is a review date, not a policy expiry date.
- **Primary discussion interest:** Understanding critical-illness lump-sum protection in addition to existing life cover.
- **Indicative monthly budget mentioned by client:** HKD 1,500. This is a discussion input, not a quote or confirmation of affordability.
- **Health disclosures:** Not supplied.
- **Training contact:** david.chan@example.invalid
- **Advisor note:** Prepare a comparison of fictional critical-illness options and questions for a licensed advisor. The snapshot does not establish whether the client has other critical-illness cover.

## Client LAB-002 — Emily Lau

- **Client ID:** LAB-002
- **Full name:** Emily Lau
- **Age stated in snapshot:** 55
- **Family context:** Married; interested in understanding spouse coverage.
- **Existing policy reference:** LAB-POL-1002
- **Existing fictional cover:** Contoso Care Medical.
- **Recorded benefit basis:** Reimbursement of eligible hospital expenses, subject to fictional policy terms. No annual monetary limit is supplied in the lab.
- **Policy status recorded in snapshot:** Active.
- **Planned advisor review date:** 8 October 2026.
- **Primary discussion interest:** Distinguishing hospital-expense reimbursement from critical-illness lump-sum protection; clarify spouse coverage with the advisor.
- **Indicative monthly budget mentioned by client:** HKD 1,000–1,500.
- **Health disclosures:** Not supplied.
- **Training contact:** emily.lau@example.invalid
- **Advisor note:** No spouse benefit is promised by the supplied coverage guide. Ask for clarification instead of inventing a family rider.

## Client LAB-003 — Michael Tam

- **Client ID:** LAB-003
- **Full name:** Michael Tam
- **Age stated in snapshot:** 35
- **Family context:** Not supplied.
- **Existing policy reference:** Not supplied.
- **Existing fictional cover:** Not supplied. Do not say that this client is uninsured.
- **Policy status recorded in snapshot:** Not supplied.
- **Planned advisor review date:** Not supplied.
- **Primary discussion interest:** Wants to understand the difference between term-life and critical-illness protection.
- **Indicative monthly budget mentioned by client:** Not supplied.
- **Health disclosures:** Not supplied.
- **Training contact:** Not supplied.
- **Advisor note:** General education can proceed, but an individualized discussion pack should identify missing needs and budget. A client message asks whether acceptance can be guaranteed. That question is not an approved product claim: the lab does not guarantee acceptance.

## Client LAB-004 — Chris Lee

- **Client ID:** LAB-004
- **Full name:** Chris Lee
- **Age stated in snapshot:** 29
- **Family context:** Single; dependants not supplied.
- **Existing policy reference:** LAB-POL-1004
- **Existing fictional cover:** Contoso Family Term 10.
- **Recorded life sum assured:** HKD 500,000.
- **Policy status recorded in snapshot:** Active.
- **Planned advisor review date:** 12 October 2026.
- **Primary discussion interest:** Understanding family income protection before a change in circumstances.
- **Indicative monthly budget mentioned by client:** HKD 800.
- **Health disclosures:** Not supplied.
- **Training contact:** chris.lee.004@example.invalid
- **Advisor note:** Name is deliberately duplicated in LAB-005. Require client ID when the user supplies only Chris Lee.

## Client LAB-005 — Chris Lee

- **Client ID:** LAB-005
- **Full name:** Chris Lee
- **Age stated in snapshot:** 47
- **Family context:** Married; one dependent child.
- **Existing policy reference:** LAB-POL-1005
- **Existing fictional cover:** Contoso Family Term 10.
- **Recorded life sum assured:** HKD 750,000.
- **Policy status recorded in snapshot:** Active.
- **Planned advisor review date:** 19 October 2026.
- **Primary discussion interest:** Understanding critical-illness protection.
- **Indicative monthly budget mentioned by client:** HKD 2,000.
- **Health disclosures:** Not supplied.
- **Training contact:** chris.lee.005@example.invalid
- **Advisor note:** Name is deliberately duplicated in LAB-004. Require client ID when the user supplies only Chris Lee.

## Source reference

When summarizing, identify the source as **Synthetic Client Snapshot, Client LAB-00X, snapshot 11 September 2026**. If the platform supplies a valid citation, retain it. Do not fabricate a URL, citation marker, or production-system reference.

## Training boundary

All participants use the same synthetic data for learning. File-upload knowledge is not a demonstration of row-level authorization, complete database queries, or live policy lookup. A production implementation needs authenticated, authorized tools against authoritative systems, freshness handling, and appropriate audit and retention controls.