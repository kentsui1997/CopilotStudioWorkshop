(() => {
  'use strict';
  const data = JSON.parse(document.getElementById('workshop-data').textContent);
  const teamInput = document.getElementById('team-key');
  const storageKey = `advisor-prep-v1-${data.audience}`;
  let state = { team: 'FSI-P01', teams: {} };
  try {
    const saved = JSON.parse(localStorage.getItem(storageKey) || 'null');
    if (saved && /^[A-Z0-9][A-Z0-9-]{1,19}$/.test(saved.team) && saved.teams && typeof saved.teams === 'object') state = saved;
  } catch { /* The portal remains usable without storage on file URLs. */ }
  teamInput.value = state.team;
  function save() { try { localStorage.setItem(storageKey, JSON.stringify(state)); } catch { /* Storage is optional. */ } }
  function toast(message) { document.getElementById('toast').textContent = message; }
  function teamTests() { return state.teams[state.team] ||= {}; }
  function substitute(text) { return text.replaceAll('{{TEAM}}', state.team); }
  function node(tag, text, className) { const el = document.createElement(tag); if (text != null) el.textContent = text; if (className) el.className = className; return el; }
  async function copy(text, fallback) {
    try {
      if (navigator.clipboard && window.isSecureContext) { await navigator.clipboard.writeText(text); toast('Copied. Paste into the indicated Copilot Studio area.'); return; }
    } catch { /* Try the local-file fallback. */ }
    const input = node('textarea'); input.value = text; input.style.position = 'fixed'; input.style.left = '-9999px'; document.body.append(input); input.select();
    let ok = false; try { ok = document.execCommand('copy'); } catch { /* Offer manual copy. */ } input.remove();
    if (!ok && fallback) { const range = document.createRange(); range.selectNodeContents(fallback); const selection = window.getSelection(); selection.removeAllRanges(); selection.addRange(range); }
    toast(ok ? 'Copied. Paste into the indicated Copilot Studio area.' : 'Clipboard unavailable. Text selected: press Ctrl+C (or Command+C).');
  }
  function renderPrompts() {
    const container = document.getElementById('prompt-cards'); container.replaceChildren();
    data.prompts.forEach((prompt, index) => {
      const details = node('details'); details.open = index === 0; details.append(node('summary', prompt.title));
      const body = node('div'); const bar = node('div', null, 'copybar'); bar.append(node('span', prompt.destination, 'tag'));
      const pre = node('pre', substitute(prompt.text), 'prompt-pre'); pre.tabIndex = 0;
      const button = node('button', 'Copy prompt'); button.type = 'button'; button.setAttribute('aria-label', `Copy ${prompt.title}`);
      button.addEventListener('click', () => copy(substitute(prompt.text), pre)); bar.append(button); body.append(bar, pre); details.append(body); container.append(details);
    });
  }
  const demoBlocks = [...document.querySelectorAll('#lab5-demo pre')].map((pre, index) => {
    const text = pre.textContent;
    const bar = node('div', null, 'copybar no-print');
    bar.append(node('span', 'Use the destination specified above this block.', 'tag'));
    const button = node('button', 'Copy demo text', 'secondary');
    button.type = 'button'; button.dataset.demoCopy = 'true';
    button.setAttribute('aria-label', `Copy Lab 5 text ${index + 1}`);
    button.addEventListener('click', () => copy(substitute(text), pre));
    bar.append(button); pre.before(bar);
    return { pre, text, button };
  });
  function renderDemoCopies() {
    demoBlocks.forEach(({ pre, text, button }) => {
      (pre.querySelector('code') || pre).textContent = substitute(text);
      button.disabled = false;
    });
  }
  function score() {
    const count = data.tests.filter(test => test.required && teamTests()[test.id]?.status === 'Pass').length;
    document.getElementById('test-score').textContent = `${count} / 8 core tests passed`;
  }
  function renderTests() {
    const container = document.getElementById('test-cards'); container.replaceChildren();
    data.tests.forEach(test => {
      const card = node('article', null, 'card test-item'); const heading = node('div', null, 'row spread');
      heading.append(node('h3', `${test.id} · ${test.category}`), node('span', test.required ? 'Required' : 'Extension', 'badge')); card.append(heading, node('p', `Where: ${test.target}`, 'tag'));
      const prompt = node('div', test.prompt, 'test-prompt'); card.append(prompt);
      const actions = node('div', null, 'row spread'); const button = node('button', 'Copy test', 'secondary'); button.type = 'button'; button.addEventListener('click', () => copy(test.prompt, prompt));
      const label = node('label', 'Result '); const select = node('select'); select.setAttribute('aria-label', `${test.id} result`);
      ['Untested', 'Pass', 'Needs work'].forEach(value => { const option = node('option', value); option.value = value; select.append(option); });
      select.value = teamTests()[test.id]?.status || 'Untested';
      select.addEventListener('change', () => { teamTests()[test.id] = { ...teamTests()[test.id], status: select.value }; save(); score(); });
      label.append(select); actions.append(button, label); card.append(actions);
      const details = node('details'); details.append(node('summary', 'Expected result and failure signals'));
      const expected = node('div'); expected.append(node('p', test.expected), node('p', `Fail if: ${test.failIf}`, 'muted')); details.append(expected); card.append(details);
      const noteLabel = node('label', 'Evidence / observation (synthetic data only)', 'tag'); const note = node('textarea', null, 'test-note'); note.setAttribute('aria-label', `${test.id} evidence`); note.value = teamTests()[test.id]?.note || '';
      note.addEventListener('input', () => { teamTests()[test.id] = { ...teamTests()[test.id], note: note.value }; save(); }); noteLabel.append(note); card.append(noteLabel); container.append(card);
    }); score();
  }
  function changeTeam() {
    const value = teamInput.value.trim().toUpperCase();
    if (!/^[A-Z0-9][A-Z0-9-]{1,19}$/.test(value)) {
      document.getElementById('team-error').textContent = 'Use 2–20 letters, digits, or hyphens; start with a letter or digit.';
      document.querySelectorAll('#prompt-cards button, [data-demo-copy]').forEach(button => { button.disabled = true; }); return;
    }
    document.getElementById('team-error').textContent = ''; state.team = value; teamInput.value = value; save();
    document.querySelectorAll('[data-agent-suffix]').forEach(el => { el.textContent = `${state.team} ${el.dataset.agentSuffix}`; }); renderPrompts(); renderDemoCopies(); renderTests();
  }
  function navigate() {
    const requested = location.hash.slice(1) || 'overview'; const panel = document.getElementById(requested);
    if (!panel || !panel.classList.contains('panel')) return;
    document.querySelectorAll('.panel').forEach(el => { el.hidden = el !== panel; });
    document.querySelectorAll('.sidebar nav a').forEach(link => { const active = link.hash === `#${requested}`; link.classList.toggle('active', active); if (active) link.setAttribute('aria-current', 'page'); else link.removeAttribute('aria-current'); });
    window.scrollTo({ top: 0, behavior: 'instant' });
  }
  teamInput.addEventListener('input', changeTeam); window.addEventListener('hashchange', navigate);
  document.getElementById('export-tests').addEventListener('click', () => {
    const lines = [`Advisor Meeting Prep — ${state.team}`, `Exported: ${new Date().toISOString()}`, 'Manual observations; not automated Copilot Studio evaluation.', ''];
    for (const test of data.tests) { const result = teamTests()[test.id] || {}; lines.push(`${test.id} ${test.category}: ${result.status || 'Untested'}`, `Observation: ${result.note || '(not recorded)'}`, ''); }
    const url = URL.createObjectURL(new Blob([lines.join('\r\n')], { type: 'text/plain;charset=utf-8' })); const link = node('a'); link.href = url; link.download = `${state.team}-Lab-Test-Notes.txt`; document.body.append(link); link.click(); link.remove(); URL.revokeObjectURL(url); toast('Test notes exported. Do not treat untested cases as passed.');
  });
  changeTeam(); navigate();
})();