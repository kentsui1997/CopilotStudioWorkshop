import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const source = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const root = path.resolve(process.env.WORKSHOP_DELIVERY || `${source}-Delivery`);
const port = Number(process.env.PORT || 8765);
const types = { '.html': 'text/html; charset=utf-8', '.txt': 'text/plain; charset=utf-8', '.md': 'text/plain; charset=utf-8', '.json': 'application/json; charset=utf-8', '.pdf': 'application/pdf', '.zip': 'application/zip', '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', '.pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation' };
const server = http.createServer((request, response) => {
  if (!['GET','HEAD'].includes(request.method)) { response.writeHead(405); response.end(); return; }
  let urlPath;
  try { urlPath = decodeURIComponent(new URL(request.url, 'http://127.0.0.1').pathname); } catch { response.writeHead(400); response.end(); return; }
  if (urlPath.split(/[\\/]/).some(part => part.startsWith('.') || part === 'tools')) { response.writeHead(403); response.end('Forbidden'); return; }
  if (urlPath.endsWith('/')) urlPath += 'index.html';
  const file = path.resolve(root, `.${urlPath}`); const relative = path.relative(root, file);
  if (relative.startsWith('..') || path.isAbsolute(relative)) { response.writeHead(403); response.end(); return; }
  if (!fs.existsSync(file) || !fs.statSync(file).isFile()) { response.writeHead(404); response.end('Not found'); return; }
  const ext = path.extname(file); const headers = { 'Content-Type': types[ext] || 'application/octet-stream', 'Content-Length': fs.statSync(file).size, 'X-Content-Type-Options': 'nosniff', 'Cache-Control': 'no-store' };
  if (['.zip','.docx','.pptx'].includes(ext)) headers['Content-Disposition'] = `attachment; filename="${path.basename(file)}"`;
  response.writeHead(200, headers); if (request.method === 'HEAD') response.end(); else fs.createReadStream(file).pipe(response);
});
server.on('error', error => { console.error(error.message); process.exitCode = 1; });
server.listen(port, '127.0.0.1', () => console.log(`Workshop delivery: http://127.0.0.1:${port}/\nLocal computer only. Share the ZIP through an approved channel for participants.`));