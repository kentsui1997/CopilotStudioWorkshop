import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { spawnSync } from 'node:child_process';

const tools = path.dirname(fileURLToPath(import.meta.url));
const root = path.dirname(tools);
const delivery = `${root}-Delivery`;
const cache = path.join(root, '.build');
for (const dir of [cache, delivery, path.join(root, 'handouts')]) fs.mkdirSync(dir, { recursive: true });
const read = file => fs.readFileSync(path.join(root, file), 'utf8').replaceAll('\r\n', '\n');
const write = (file, content) => { fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, content); };
const escape = value => String(value).replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;');
const css = read('tools/site.css');
const pandoc = process.env.PANDOC || 'pandoc';
function run(command, args, options = {}) {
  const result = spawnSync(command, args, { cwd: root, encoding: 'utf8', maxBuffer: 12 * 1024 * 1024, windowsHide: true, ...options });
  if (result.error || result.status !== 0) throw new Error(`${command} failed: ${result.error?.message || result.stderr || result.status}`);
  return result.stdout;
}
console.log(run(pandoc, ['--version']).split('\n')[0]);
function markdown(text, flavor = 'gfm') { return run(pandoc, ['--from', flavor, '--to', 'html5', '--wrap', 'none'], { input: text }); }
function htmlLinks(html) {
  return html.replace(/href="([^"#]+)\.md(#[^"]*)?"/g, (match, target, hash = '') => /^https?:/i.test(target) ? match : `href="${target}.html${hash}"`);
}
function page(title, content, home = 'START-HERE.html') {
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escape(title)}</title><style>${css}</style></head><body><div class="doc-toolbar no-print"><a class="button secondary" href="${home}">Workshop portal</a><button onclick="print()">Print / save PDF</button></div><main class="document-wrapper"><article class="document">${content}</article></main></body></html>`;
}
const promptNames = [
  ['00-Builder.txt', 'Builder prompt — four agent shells', 'Paste into Copilot Studio Home / builder chat'],
  ['01-Hub-Instructions.txt', 'Hub — full runtime instructions', 'Paste into Hub → Build → Instructions (replace starter text)'],
  ['02-Client-Briefing-Instructions.txt', 'Client Briefing — full runtime instructions', 'Paste into Client Briefing → Build → Instructions'],
  ['03-Coverage-Guide-Instructions.txt', 'Coverage Guide — full runtime instructions', 'Paste into Coverage Guide → Build → Instructions'],
  ['04-Follow-up-Drafting-Instructions.txt', 'Follow-up Drafting — full runtime instructions', 'Paste into Follow-up Drafting → Build → Instructions'],
  ['05-Workflow-Builder.txt', 'Optional workflow builder', 'Optional: paste into builder chat, not Preview'],
  ['06-Workflow-Agent-Delta.txt', 'Optional workflow agent delta', 'Optional: append to Follow-up Drafting instructions; do not replace them']
];
const prompts = promptNames.map(([file, title, destination]) => ({ file, title, destination, text: read(`prompts/${file}`).trim() }));
const tests = JSON.parse(read('tests/cases.json'));
if (tests.length !== 14 || tests.filter(test => test.required).length !== 8) throw new Error('Expected 14 test cases, eight required.');
const advancedPromptNames = [
  ['00-Email-Hub-Builder.txt', 'Advanced Email Hub — shell builder', 'Optional: Home builder chat; no tool binding or send'],
  ['01-Email-Hub-Instructions.txt', 'Advanced Email Hub — full instructions', 'NEW Email Hub → Build → Instructions; replace starter text, not the core Hub'],
  ['02-Send-Tool-Description.txt', 'Send Reviewed Lab Email — tool description', 'NEW Email Hub → send action Tool details → Description'],
  ['03-Outlook-Draft-Handoff-Instructions.txt', 'Path B — manual Outlook send fallback', 'Alternative new Draft Hub → Instructions; omit/remove every send tool']
];
const advancedPrompts = advancedPromptNames.map(([file, title, destination]) => ({ file, title, destination, text: read(`advanced-email/prompts/${file}`).trim() }));
const advancedTests = JSON.parse(read('advanced-email/tests/cases.json'));
if (advancedTests.length !== 10) throw new Error('Expected ten separate advanced-email test cases.');
const sources = [
  'README.md', '01-Participant-Lab.md', '02-Instructor-Runbook.md', '03-Tenant-Preflight.md',
  '04-Optional-Workflow.md', '06-Test-Checklist.md', '07-Sources-and-Feature-Notes.md', '08-Lab5-Instructor-Demo.md',
  '09-T08-Advanced-Outlook-Send.md', 'advanced-email/README.md',
  'knowledge/01-Synthetic-Client-Snapshot.md', 'knowledge/02-Fictional-Coverage-Guide.md', 'knowledge/03-Communication-Standard.md'
];
for (const source of sources) {
  const text = read(source); const title = text.match(/^# (.+)$/m)?.[1] || source;
  const home = source.startsWith('knowledge/') ? '../START-HERE.html#knowledge' : source.includes('/') ? '../START-HERE.html' : 'START-HERE.html';
  write(path.join(root, source.replace(/\.md$/, '.html')), page(title, htmlLinks(markdown(text)), home));
}
function wrap(text, width = 88) {
  return text.split('\n').map(line => {
    if (line.length <= width) return line;
    const words = line.split(/\s+/); const lines = []; let current = '';
    for (const word of words) { if (current && current.length + word.length + 1 > width) { lines.push(current); current = word; } else current += `${current ? ' ' : ''}${word}`; }
    if (current) lines.push(current); return lines.join('\n');
  }).join('\n');
}
const appendix = '\n\n# Appendix — Full Copy-and-Paste Prompt Book\n\nReplace every {{TEAM}} with your assigned team key before pasting. The offline portal performs this substitution automatically. Paste builder prompts into Home chat, runtime instructions into Build, and test prompts into Preview.\n\n' + prompts.map(prompt => `## ${prompt.title}\n\n**${prompt.destination}**\n\n~~~text\n${wrap(prompt.text)}\n~~~\n`).join('\n');
const participant = read('01-Participant-Lab.md') + appendix;
const advancedAppendix = '\n\n# Appendix — Advanced Email Full Prompt Book\n\nOpt-in real-email exercise only. Replace {{TEAM}} and {{TEST_RECIPIENT}} before pasting. These are not changes to the core Hub or draft-only specialists. The Path B prompt is an alternative, not an additional sending rule.\n\n' + advancedPrompts.map(prompt => `## ${prompt.title}\n\n**${prompt.destination}**\n\n~~~text\n${wrap(prompt.text)}\n~~~\n`).join('\n');
const handoutSpecs = [
  ['Participant-Lab', participant],
  ['Instructor-Runbook', read('02-Instructor-Runbook.md')],
  ['Lab5-Instructor-Demo', read('08-Lab5-Instructor-Demo.md')],
  ['Advanced-Outlook-Send', read('09-T08-Advanced-Outlook-Send.md') + advancedAppendix],
  ['Tenant-Preflight', read('03-Tenant-Preflight.md')],
  ['Optional-Workflow', read('04-Optional-Workflow.md')],
  ['Test-Checklist', read('06-Test-Checklist.md')]
];
function linksForHandout(text) {
  return text.replace(/\]\(([^)]+)\)/g, (match, target) => /^(?:https?:|#|mailto:)/i.test(target) ? match : `](../${target})`);
}
for (const [name, text] of handoutSpecs) {
  run(pandoc, ['--from', 'markdown', '--to', 'docx', '--toc', '--toc-depth', '2', '--output', path.join(root, 'handouts', `${name}.docx`)], { input: linksForHandout(text) });
  const html = htmlLinks(markdown(linksForHandout(text), 'markdown'));
  write(path.join(root, 'handouts', `${name}.html`), page(name.replaceAll('-', ' '), html, '../START-HERE.html'));
}
for (const source of sources.filter(file => file.startsWith('knowledge/'))) {
  run(pandoc, ['--from', 'markdown', '--to', 'docx', '--output', path.join(root, source.replace(/\.md$/, '.docx'))], { input: read(source) });
}
const slideSource = read('05-Facilitator-Slides.md');
run(pandoc, ['--from', 'markdown+fenced_divs', '--to', 'pptx', '--slide-level', '2', '--output', path.join(root, 'handouts', 'Facilitator-Slides.pptx')], { input: slideSource });
const slideParts = slideSource.trim().split(/^## /m).filter(Boolean);
if (slideParts.length !== 14) throw new Error(`Expected 14 slides, got ${slideParts.length}`);
const slideHtml = slideParts.map((part, index) => {
  const content = markdown(`## ${part}`, 'markdown+fenced_divs');
  return `<section class="slide${index === 0 ? ' active' : ''}" aria-label="Slide ${index + 1}"><div class="kicker">Copilot Studio workshop · 11 September 2026</div>${content}<div class="smallprint">Fictional Contoso Assurance training content · Not Manulife products, policies, or customer data</div></section>`;
}).join('\n');
const deckScript = `(() => { let current = 0; const slides = [...document.querySelectorAll('.slide')]; function show(index) { current = Math.max(0, Math.min(slides.length - 1, index)); slides.forEach((slide, i) => { slide.classList.toggle('active', i === current); slide.querySelectorAll('.notes').forEach(note => note.classList.remove('show')); }); document.getElementById('counter').textContent = (current + 1) + ' / ' + slides.length; } document.getElementById('prev').onclick = () => show(current - 1); document.getElementById('next').onclick = () => show(current + 1); document.getElementById('notes').onclick = () => slides[current].querySelector('.notes')?.classList.toggle('show'); document.addEventListener('keydown', event => { if (['ArrowRight','PageDown'].includes(event.key)) { event.preventDefault(); show(current + 1); } else if (['ArrowLeft','PageUp'].includes(event.key)) { event.preventDefault(); show(current - 1); } else if (event.key === 'Home') show(0); else if (event.key === 'End') show(slides.length - 1); }); show(0); })();`;
write(path.join(root, '05-Facilitator-Slides.html'), `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Advisor Meeting Prep | Facilitator slides</title><style>${read('tools/slides.css')}</style></head><body>${slideHtml}<div class="deck-toolbar"><a href="START-HERE.html#facilitator">Workshop portal</a><span>Arrow keys / Page Up / Page Down</span><div class="nav-buttons"><button id="notes">Speaker notes</button><button id="prev" aria-label="Previous slide">←</button><span id="counter">1 / 14</span><button id="next" aria-label="Next slide">→</button></div></div><script>${deckScript}</script></body></html>`);
function advancedPanel(standalone = false) {
  const teamField = standalone ? '<div><label for="advanced-team-key">Existing specialist team key</label><br><input id="advanced-team-key" value="FSI-DEMO" maxlength="20" autocomplete="off" spellcheck="false"></div>' : '<p>Use the team key in the left sidebar for the existing three specialists.</p>';
  return `<section id="advanced-email"${standalone ? '' : ' class="panel" hidden'}>
    <p class="eyebrow">Opt-in extension · Real email requires explicit permission</p>
    <h1>Review. Approve. Send<br>from your own Outlook.</h1>
    <p>One extra <strong id="advanced-email-agent-name">FSI-DEMO Email Hub</strong> reuses your three specialists. Original T08 and the core Hub stay draft-only. Booking and business logging stay unavailable.</p>
    <div class="notice"><strong>REAL EMAIL WARNING:</strong> these instructions can enable actual Outlook sends in Copilot Studio. Use only an approved internal training recipient and an end-user connection verified with a non-maker account. This portal only copies text; it never sends email.</div>
    <div class="row"><a class="button" href="handouts/Advanced-Outlook-Send.pdf">Download advanced guide + prompts · PDF</a><a class="button secondary" href="handouts/Advanced-Outlook-Send.docx">Editable Word</a></div>
    <div class="card" style="margin-top:24px"><h2 style="margin-top:0">Set copy values deliberately</h2>${teamField}
      <label for="advanced-test-recipient">Approved internal test recipient</label><br><input id="advanced-test-recipient" type="email" placeholder="Your approved training mailbox" autocomplete="off" spellcheck="false" aria-describedby="advanced-recipient-note" style="width:min(100%,480px)">
      <p id="advanced-recipient-note" class="legend">Recipient not configured. Placeholder-based send text cannot be copied yet.</p>
      <p class="legend">This is text substitution only—not OAuth, an enforced allowlist, or message approval. Configure the same fixed To in the tool; never enter a password or token here.</p>
      <p id="advanced-copy-status" role="status" aria-live="polite"></p>
    </div>
    <h2>Copy the advanced prompts</h2><p>Only the new Email Hub gets the send action. Do not paste these instructions into the original Hub or the existing Drafting specialist.</p>
    <div id="advanced-email-prompts"></div>
    <div id="advanced-email-guide" class="document">${htmlLinks(markdown(read('09-T08-Advanced-Outlook-Send.md')))}</div>
    <h2>Ten separate manual advanced checks</h2><div class="notice">T08-A3 and T08-A6 can send actual messages after approval. Run manually with controlled mailboxes. Do not run these as unattended evaluations. Recording Pass here is a manual observation, not an automated test.</div>
    <div id="advanced-email-tests"></div>
    <script id="advanced-email-data" type="application/json">${JSON.stringify({ prompts: advancedPrompts, tests: advancedTests }).replaceAll('<', '\\u003c')}</script>
  </section>`;
}
function portal(audience) {
  const facilitator = audience === 'Facilitator';
  const facilitatorPanel = `<section id="facilitator" class="panel" hidden>
    <p class="eyebrow">Facilitator desk</p><h1>Ready for the workshop.</h1>
    <p>Rehearse with a representative participant account before the session. Local file validation does not establish tenant readiness.</p>
    <div class="notice"><strong>Hard gate:</strong> create → upload → publish specialist → connect → invoke. Keep the finished FSI-DEMO set separate from FSI-LIVE.</div>
    <div class="download-list">
      <a href="#advanced-email">T08-Advanced · Set up approved email sending from the user's Outlook</a>
      <a href="handouts/Advanced-Outlook-Send.pdf">Advanced Outlook email guide + prompts · PDF</a>
      <a href="#lab5-demo">NEW · Lab 5: four-challenge setup and live demo (with copy buttons)</a>
      <a href="handouts/Lab5-Instructor-Demo.pdf">Lab 5 instructor demo · PDF</a>
      <a href="handouts/Lab5-Instructor-Demo.docx">Lab 5 instructor demo · Editable Word</a>
      <a href="03-Tenant-Preflight.html">Tenant preflight and go/no-go</a>
      <a href="02-Instructor-Runbook.html">Minute-by-minute instructor runbook + illustrative answer key</a>
      <a href="05-Facilitator-Slides.html">Present the 14-slide browser deck</a>
      <a href="handouts/Facilitator-Slides.pptx">Download editable PowerPoint slides</a>
      <a href="handouts/Facilitator-Slides.pdf">Download slides as PDF</a>
      <a href="handouts/Instructor-Runbook.pdf">Instructor runbook · PDF</a>
      <a href="handouts/Tenant-Preflight.pdf">Tenant preflight · PDF</a>
      <a href="07-Sources-and-Feature-Notes.html">Documentation and verification boundaries</a>
    </div>
    <h2>Opening demo plan</h2><ol class="steps"><li>Show the completed LAB-001 pack and actual specialist calls.</li><li>Create one Drafting specialist; paste instructions, attach knowledge, publish.</li><li>Connect it to the prepared live Hub.</li><li>Demonstrate the no-send boundary, then hand over at minute 25.</li></ol>
    <p class="muted">Distribute the participant ZIP, not this facilitator edition. A localhost preview link does not work for attendees on other computers.</p>
  </section>
  <section id="lab5-demo" class="panel" hidden>
    <div class="row spread"><p class="eyebrow">Instructor-only · T05–T08</p><a class="button secondary" href="handouts/Lab5-Instructor-Demo.pdf">Download Lab 5 PDF</a></div>
    <div class="notice success-note">Setup blocks → <strong>Build → Instructions</strong>. Challenge messages → <strong>Preview</strong>. Read the destination above each block. Copy buttons substitute your selected team key.</div>
    <div class="document">${htmlLinks(markdown(read('08-Lab5-Instructor-Demo.md')))}</div>
  </section>${advancedPanel()}`;
  const replacements = {
    CSS: css,
    AUDIENCE: audience,
    LAB: htmlLinks(markdown(read('01-Participant-Lab.md'))),
    EXTENSION: htmlLinks(markdown(read('04-Optional-Workflow.md'))),
    FACILITATOR_NAV: facilitator ? '<a href="#facilitator">07 · Facilitator desk</a><a href="#lab5-demo">08 · Lab 5 demo</a><a href="#advanced-email">09 · Advanced Outlook email</a>' : '',
    FACILITATOR_PANEL: facilitator ? facilitatorPanel : '',
    DATA: JSON.stringify({ audience, prompts, tests }).replaceAll('<', '\\u003c'),
    JS: read('tools/portal.js') + (facilitator ? '\n' + read('tools/advanced-email.js') : '')
  };
  return read('tools/portal.html').replace(/@@([A-Z_]+)@@/g, (_, key) => { if (!(key in replacements)) throw new Error(`Unknown template token ${key}`); return replacements[key]; });
}
write(path.join(root, 'START-HERE.html'), portal('Facilitator'));

const edge = [process.env.EDGE, 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe', 'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe'].find(file => file && fs.existsSync(file));
if (!edge) throw new Error('Microsoft Edge was not found for PDF generation.');
const pdfCounts = {};
for (const name of [...handoutSpecs.map(([name]) => name), 'Facilitator-Slides']) {
  const input = name === 'Facilitator-Slides' ? path.join(root, '05-Facilitator-Slides.html') : path.join(root, 'handouts', `${name}.html`);
  const output = path.join(root, 'handouts', `${name}.pdf`);
  // Reuse only when the change affects the portal, not printed document content.
  if (!process.argv.includes('--reuse-pdfs')) {
    run(edge, ['--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check', '--no-pdf-header-footer', `--user-data-dir=${path.join(cache, `edge-${name}`)}`, `--print-to-pdf=${output}`, pathToFileURL(input).href], { timeout: 120000 });
  }
  const pdf = fs.readFileSync(output);
  if (pdf.subarray(0, 5).toString() !== '%PDF-') throw new Error(`Invalid PDF: ${name}`);
  pdfCounts[name] = [...pdf.toString('latin1').matchAll(/\/Type\s*\/Page\b/g)].length;
  if (!pdfCounts[name]) throw new Error(`PDF page count unavailable: ${name}`);
  if (name === 'Facilitator-Slides' && pdfCounts[name] !== 14) throw new Error(`Slides PDF has ${pdfCounts[name]} pages, expected 14.`);
  console.log(`PDF ${name}: ${pdfCounts[name]} pages`);
}

const participantReadme = `# Advisor Meeting Prep — Participant Pack\n\n**Manulife workshop | 11 September 2026 | Fictional Contoso Assurance training only**\n\n1. Extract the entire ZIP.\n2. Open [START-HERE.html](START-HERE.html) in your browser. No installation is required for the pack.\n3. Set your assigned team key and follow the participant lab.\n4. Download the three knowledge DOCX files from the portal and upload one to each assigned specialist.\n5. Use the PDF/Word handouts when preferred. The participant handout contains all seven copy-and-paste prompts in its appendix.\n\nThe portal is offline; Copilot Studio requires internet, an approved environment, credits, and an account that can publish and invoke specialists. Trial-only Preview may not support the full exercise. No real customer data, product terms, or business writes are needed.\n\nThe local test worksheet is not an automated agent evaluation. Current feature documentation and limitations are in [Sources and Feature Notes](07-Sources-and-Feature-Notes.html). This pack is not a Copilot Studio importable solution.\n`;
const core = ['01-Participant-Lab', '04-Optional-Workflow', '06-Test-Checklist', '07-Sources-and-Feature-Notes'];
function copyRelative(source, destination, file) {
  const target = path.join(destination, file); fs.mkdirSync(path.dirname(target), { recursive: true }); fs.copyFileSync(path.join(source, file), target);
}
function listFiles(dir, base = dir) {
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap(entry => entry.isDirectory() ? listFiles(path.join(dir, entry.name), base) : [path.relative(base, path.join(dir, entry.name)).replaceAll('\\', '/')]);
}
for (const audience of ['Participant', 'Facilitator']) {
  const target = path.join(delivery, `${audience}-Pack`); fs.mkdirSync(target, { recursive: true });
  const bases = audience === 'Facilitator' ? [...core, 'README', '02-Instructor-Runbook', '03-Tenant-Preflight', '05-Facilitator-Slides', '08-Lab5-Instructor-Demo', '09-T08-Advanced-Outlook-Send'] : core;
  for (const base of bases) for (const ext of ['md', 'html']) copyRelative(root, target, `${base}.${ext}`);
  for (const folder of ['knowledge', 'prompts', 'tests']) for (const file of listFiles(path.join(root, folder))) copyRelative(root, target, `${folder}/${file}`);
  const handouts = audience === 'Facilitator' ? listFiles(path.join(root, 'handouts')) : listFiles(path.join(root, 'handouts')).filter(file => /^(Participant-Lab|Optional-Workflow|Test-Checklist)\./.test(file));
  for (const file of handouts) copyRelative(root, target, `handouts/${file}`);
  if (audience === 'Facilitator') {
    for (const file of listFiles(tools)) copyRelative(root, target, `tools/${file}`);
    for (const file of listFiles(path.join(root, 'advanced-email'))) copyRelative(root, target, `advanced-email/${file}`);
  }
  else { write(path.join(target, 'README.md'), participantReadme); write(path.join(target, 'README.html'), page('Participant Pack', markdown(participantReadme))); }
  write(path.join(target, 'START-HERE.html'), portal(audience));
}
const advancedTarget = path.join(delivery, 'Advanced-Email-Pack'); fs.mkdirSync(path.join(advancedTarget, 'handouts'), { recursive: true });
for (const ext of ['md', 'html']) copyRelative(root, advancedTarget, `09-T08-Advanced-Outlook-Send.${ext}`);
for (const ext of ['docx', 'html', 'pdf']) copyRelative(root, advancedTarget, `handouts/Advanced-Outlook-Send.${ext}`);
for (const file of listFiles(path.join(root, 'advanced-email'))) copyRelative(root, advancedTarget, `advanced-email/${file}`);
const advancedReadme = '# T08-Advanced — Outlook Email Supplement\n\n**OPT-IN: CAN SEND REAL EMAIL.** Requires a completed core workshop and separately approved Outlook identity/recipient/approval configuration.\n\nExtract this entire ZIP and open [START-HERE.html](START-HERE.html). It contains the click-by-click guide, full new-Hub prompts, ten manual tests, PDF/Word handouts, and a manual-Outlook-send fallback. Copy buttons never send email. Configure the real tool only in the approved Copilot Studio environment.\n\nOne new Email Hub reuses the existing three specialists. Do not modify the original no-write Hub or core T08 tests. Keep booking/logging unavailable. Verify actual sender identity with a non-maker user and a controlled training recipient.\n\nThe exact per-run confirmation toggle is not verified in the new-harness docs; do not present instruction-only chat approval as deterministic enforcement. No tenant connections, agents, or emails were created by this pack-generation process.\n';
write(path.join(advancedTarget, 'README.md'), advancedReadme);
write(path.join(advancedTarget, 'README.html'), page('Advanced email supplement', markdown(advancedReadme)));
write(path.join(advancedTarget, 'START-HERE.html'), page('T08-Advanced | Approve and send from my Outlook', advancedPanel(true) + `<script>${read('tools/advanced-email.js')}</script>`));
const landing = `<div class="eyebrow">Workshop delivery · 11 September 2026</div><h1>Advisor Meeting Prep</h1><p>Four connected Copilot Studio agents. A two-hour workshop with synthetic insurance data, copyable prompts, upload-ready knowledge, and instructor materials.</p><div class="notice success-note"><strong>Use the participant ZIP for distribution.</strong> Extract it and open START-HERE in a browser. Copilot Studio still needs tenant access. This local preview link is only for this computer.</div><div class="grid"><div class="card"><h3>Participant pack</h3><p>Offline lab portal, PDF/Word handouts, three knowledge DOCX files, prompts, and tests.</p><a class="button" href="Advisor-Meeting-Prep-Participant-Pack.zip" download>Download participant ZIP</a><p class="legend"><a href="Participant-Pack/START-HERE.html">Preview participant portal</a></p></div><div class="card"><h3>Facilitator pack</h3><p>Everything above plus runbook, preflight, answer key, 14-slide presentation, and sources.</p><a class="button" href="Advisor-Meeting-Prep-Facilitator-Pack.zip" download>Download facilitator ZIP</a><p class="legend"><a href="Facilitator-Pack/START-HERE.html#facilitator">Open facilitator desk</a></p></div><div class="card"><h3>Check tonight</h3><p>Verify that a representative participant can publish and invoke specialists. Trial-only Preview may not be enough.</p><a class="button secondary" href="Facilitator-Pack/03-Tenant-Preflight.html">Open tenant preflight</a><p class="legend"><a href="Facilitator-Pack/handouts/Facilitator-Slides.pptx">Editable PowerPoint</a></p></div></div><h2>Verification boundary</h2><p>Local files are generated and checked; Copilot Studio agents have not been created or runtime-tested in your tenant by this process. Run the preflight and instructor rehearsal before class.</p><p class="muted">All products, profiles, and standards are fictional Contoso Assurance training content—not Manulife products, policies, or customer records.</p>`;
const advancedLanding = '<h2>Opt-in advanced email supplement</h2><div class="notice"><strong>Real-email exercise, distributed separately:</strong> add one Email Hub with an end-user Outlook send action after identity and approval preflight. The core pack remains no-write.</div><div class="row"><a class="button" href="Advisor-Meeting-Prep-Advanced-Email-Pack.zip" download>Download advanced email ZIP</a><a class="button secondary" href="Advanced-Email-Pack/START-HERE.html">Open advanced email guide</a></div>';
write(path.join(delivery, 'index.html'), page('Workshop delivery', landing + advancedLanding, 'Facilitator-Pack/START-HERE.html'));
const report = { builtAt: new Date().toISOString(), documentationChecked: '2026-09-11', workshopDate: '2026-09-11', agents: 4, knowledgeDocuments: 3, prompts: prompts.length, slides: slideParts.length, tests: tests.length, requiredTests: 8, advancedEmail: { extraHubs: 1, reusedSpecialists: 3, prompts: advancedPrompts.length, manualTests: advancedTests.length, realEmailOptIn: true, tenantRuntime: 'NOT TESTED' }, pdfPages: pdfCounts, tenantRuntime: 'NOT TESTED — facilitator preflight and rehearsal required', browserValidation: 'Run separately after generation' };
write(path.join(delivery, 'build-report.json'), JSON.stringify(report, null, 2));
console.log(`Generated source pack and delivery folders: ${delivery}`);
console.log('Next: validate links, validate Office packages, create ZIP archives, and check the portal in a browser.');