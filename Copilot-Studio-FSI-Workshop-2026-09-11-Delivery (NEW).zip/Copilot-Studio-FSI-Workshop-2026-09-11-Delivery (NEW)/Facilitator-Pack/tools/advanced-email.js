(() => {
  'use strict';
  const source = document.getElementById('advanced-email-data');
  if (!source) return;
  const data = JSON.parse(source.textContent);
  const team = document.getElementById('advanced-team-key') || document.getElementById('team-key');
  const recipient = document.getElementById('advanced-test-recipient');
  const status = document.getElementById('advanced-copy-status');
  const buttons = [];
  const blocks = [];
  const key = 'advisor-email-worksheet-v1';
  let saved = {};
  try { saved = JSON.parse(localStorage.getItem(key) || '{}'); } catch { /* Offline storage is optional. */ }
  function persist() { try { localStorage.setItem(key, JSON.stringify(saved)); } catch { /* Keep the worksheet usable. */ } }
  function node(tag, text, className) { const element = document.createElement(tag); if (text != null) element.textContent = text; if (className) element.className = className; return element; }
  function prefix() { return team.value.trim().toUpperCase(); }
  function teamValid() { return /^[A-Z0-9][A-Z0-9-]{1,19}$/.test(prefix()); }
  function addressValid() {
    const address = recipient.value.trim();
    if (!/^[^\s<>@;,]+@[^\s<>@;,]+\.[^\s<>@;,]+$/.test(address)) return false;
    const domain = address.split('@')[1].toLowerCase();
    return !/(?:\.(?:invalid|example|test)|(?:^|\.)example\.(?:com|org|net))$/.test(domain);
  }
  function substitute(text) { return text.replaceAll('{{TEAM}}', prefix()).replaceAll('{{TEST_RECIPIENT}}', recipient.value.trim() || '{{TEST_RECIPIENT}}'); }
  function mayCopy(text) { return teamValid() && (!text.includes('{{TEST_RECIPIENT}}') || addressValid()); }
  async function copy(text, pre) {
    if (!mayCopy(text)) { status.textContent = 'Set a valid team key and replace the approved test-recipient placeholder first.'; return; }
    const value = substitute(text);
    try {
      if (navigator.clipboard && window.isSecureContext) { await navigator.clipboard.writeText(value); status.textContent = 'Copied text only. Nothing was sent. Paste into the specified Copilot Studio area.'; return; }
    } catch { /* Local-file clipboard fallback. */ }
    const input = node('textarea'); input.value = value; input.style.position = 'fixed'; input.style.left = '-9999px'; document.body.append(input); input.select();
    let ok = false; try { ok = document.execCommand('copy'); } catch { /* Manual copy remains available. */ } input.remove();
    if (!ok && pre) { const range = document.createRange(); range.selectNodeContents(pre); const selection = window.getSelection(); selection.removeAllRanges(); selection.addRange(range); }
    status.textContent = ok ? 'Copied text only. Nothing was sent.' : 'Text selected. Press Ctrl+C / Command+C. Nothing was sent.';
  }
  function copyButton(text, pre, label) {
    const button = node('button', 'Copy text', 'secondary'); button.type = 'button'; button.setAttribute('aria-label', label); button.dataset.advancedCopy = 'true';
    button.addEventListener('click', () => copy(text, pre)); buttons.push({ button, text }); return button;
  }
  document.querySelectorAll('#advanced-email-guide pre').forEach((pre, index) => {
    const text = pre.textContent; const bar = node('div', null, 'copybar no-print');
    bar.append(node('span', 'Use the destination specified above this block.', 'tag'), copyButton(text, pre, `Copy advanced demo ${index + 1}`)); pre.before(bar); blocks.push({ pre, text });
  });
  const prompts = document.getElementById('advanced-email-prompts');
  data.prompts.forEach((prompt, index) => {
    const details = node('details'); details.open = index === 1; details.append(node('summary', prompt.title));
    const body = node('div'); const pre = node('pre', substitute(prompt.text), 'prompt-pre'); const bar = node('div', null, 'copybar');
    bar.append(node('span', prompt.destination, 'tag'), copyButton(prompt.text, pre, `Copy advanced prompt ${index + 1}`)); body.append(bar, pre); details.append(body); prompts.append(details); blocks.push({ pre, text: prompt.text });
  });
  const testContainer = document.getElementById('advanced-email-tests');
  const testControls = [];
  data.tests.forEach(test => {
    const article = node('article', null, 'card test-item'); const heading = node('div', null, 'row spread');
    heading.append(node('h3', `${test.id} · ${test.category}`), node('span', test.maySend ? 'REAL SEND after approval' : 'No send expected', 'badge'));
    const text = node('div', substitute(test.prompt), 'test-prompt'); blocks.push({ pre: text, text: test.prompt });
    const actions = node('div', null, 'row spread'); const select = node('select'); select.setAttribute('aria-label', `${test.id} advanced result`);
    for (const item of ['Untested', 'Pass', 'Needs work', 'Not applicable — Path B']) { const option = node('option', item); option.value = item; select.append(option); }
    select.addEventListener('change', () => { if (!teamValid()) return; (saved[prefix()] ||= {})[test.id] = select.value; persist(); });
    actions.append(copyButton(test.prompt, text, `Copy ${test.id} scenario`), select);
    const details = node('details'); details.append(node('summary', 'Expected evidence / failure signals')); const info = node('div'); info.append(node('p', test.expected), node('p', `Fail if: ${test.failIf}`, 'muted')); details.append(info);
    article.append(heading, node('p', test.target, 'tag'), text, actions, details); testContainer.append(article); testControls.push({ select, id: test.id });
  });
  function update() {
    document.getElementById('advanced-email-agent-name').textContent = `${teamValid() ? prefix() : '{{TEAM}}'} Email Hub`;
    blocks.forEach(({ pre, text }) => { (pre.querySelector('code') || pre).textContent = substitute(text); });
    buttons.forEach(({ button, text }) => { button.disabled = !mayCopy(text); });
    testControls.forEach(({ select, id }) => { select.value = saved[prefix()]?.[id] || 'Untested'; });
    document.getElementById('advanced-recipient-note').textContent = addressValid()
      ? 'Address syntax accepted only. This portal has NOT verified ownership, internal status, permission, or delivery. Configure the same fixed To in Copilot Studio.'
      : 'Enter one real, approved internal training address. Reserved example/invalid addresses are not send targets. No addresses are saved by this field.';
  }
  team.addEventListener('input', update); recipient.addEventListener('input', update); update();
})();