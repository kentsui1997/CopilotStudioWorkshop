import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';

const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const delivery = `${root}-Delivery`;
const errors = [];
let checkedLinks = 0;
function files(dir, base = dir) {
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap(entry => entry.isDirectory() ? files(path.join(dir, entry.name), base) : [path.relative(base, path.join(dir, entry.name))]);
}
for (const audience of ['Participant', 'Facilitator', 'Advanced-Email']) {
  const dir = path.join(delivery, `${audience}-Pack`);
  for (const file of files(dir).filter(file => file.endsWith('.html') && !file.startsWith(`tools${path.sep}`))) {
    const full = path.join(dir, file); const html = fs.readFileSync(full, 'utf8');
    if (/@@[A-Z_]+@@/.test(html)) errors.push(`${file}: unexpanded template token`);
    for (const pattern of html.matchAll(/\bpattern="([^"]+)"/g)) {
      try { new RegExp(pattern[1], 'v'); } catch (error) { errors.push(`${file}: invalid HTML input pattern: ${error.message}`); }
    }
    for (const match of html.matchAll(/(?:href|src)="([^"<>]+)"/g)) {
      let target = match[1].replaceAll('&amp;', '&');
      if (/^(?:https?:|mailto:|data:|blob:|javascript:|#)/i.test(target)) continue;
      target = decodeURIComponent(target.split(/[?#]/)[0]); if (!target) continue;
      checkedLinks++;
      if (!fs.existsSync(path.resolve(path.dirname(full), target))) errors.push(`${audience}/${file}: missing ${target}`);
    }
    for (const script of html.matchAll(/<script(?![^>]*type="application\/json")[^>]*>([\s\S]*?)<\/script>/g)) {
      try { new vm.Script(script[1], { filename: file }); } catch (error) { errors.push(`${file}: ${error.message}`); }
    }
  }
  const portal = fs.readFileSync(path.join(dir, 'START-HERE.html'), 'utf8');
  if (audience !== 'Participant') {
    const advanced = JSON.parse(portal.match(/<script id="advanced-email-data" type="application\/json">([\s\S]*?)<\/script>/)[1]);
    assert.equal(advanced.prompts.length, 4); assert.equal(advanced.tests.length, 10);
    assert.equal(new Set(advanced.tests.map(test => test.id)).size, 10);
    assert.equal(advanced.tests.filter(test => test.maySend).length, 2);
    for (const prompt of advanced.prompts) {
      assert(prompt.text.includes('{{TEAM}}'));
      assert(!prompt.text.replaceAll('{{TEAM}}', 'FSI-QA').replaceAll('{{TEST_RECIPIENT}}', 'qa@contoso.com').includes('{{'));
    }
    for (const file of ['09-T08-Advanced-Outlook-Send.html', 'handouts/Advanced-Outlook-Send.pdf', 'handouts/Advanced-Outlook-Send.docx']) assert(fs.existsSync(path.join(dir, file)), `Missing advanced-email deliverable: ${file}`);
    assert(portal.includes('REAL EMAIL WARNING'));
  }
  if (audience === 'Advanced-Email') {
    assert(!portal.includes('id="workshop-data"'), 'Core no-write guide unexpectedly merged into advanced supplement');
    continue;
  }
  const data = JSON.parse(portal.match(/<script id="workshop-data" type="application\/json">([\s\S]*?)<\/script>/)[1]);
  assert.equal(data.prompts.length, 7); assert.equal(data.tests.length, 14); assert.equal(data.tests.filter(test => test.required).length, 8);
  for (const prompt of data.prompts) { assert(prompt.text.includes('{{TEAM}}')); assert(!prompt.text.replaceAll('{{TEAM}}', 'FSI-QA').includes('{{TEAM}}')); }
  if (audience === 'Participant') {
    assert(!portal.includes('id="facilitator"'));
    assert(!portal.includes('id="lab5-demo"'));
    assert(!portal.includes('id="advanced-email-data"'));
    assert(!files(dir).some(file => /Instructor-Runbook|Tenant-Preflight|Facilitator-Slides|Lab5-Instructor-Demo|Advanced-Outlook-Send|advanced-email/.test(file)), 'Instructor or opt-in real-email material leaked into core participant ZIP');
  } else {
    assert(portal.includes('id="lab5-demo"'), 'Lab 5 demo missing from facilitator portal');
    for (const file of ['08-Lab5-Instructor-Demo.html', 'handouts/Lab5-Instructor-Demo.pdf', 'handouts/Lab5-Instructor-Demo.docx']) assert(fs.existsSync(path.join(dir, file)), `Missing Lab 5 deliverable: ${file}`);
  }
}
const lab5 = fs.readFileSync(path.join(root, '08-Lab5-Instructor-Demo.md'), 'utf8');
for (const id of ['T05', 'T06', 'T07', 'T08']) assert(lab5.includes(`Challenge ${id}`), `Missing instructor challenge: ${id}`);
assert(lab5.includes('**same conversation**'));
assert(lab5.includes('Manage/remove tool associations'));
const emailGuide = fs.readFileSync(path.join(root, '09-T08-Advanced-Outlook-Send.md'), 'utf8');
for (const text of ['one additional', 'Leave From (Send as) blank', 'standard-harness', 'SEND STATUS UNKNOWN', 'Path B', 'end user B']) assert(emailGuide.includes(text), `Advanced email safeguard missing: ${text}`);
assert(!fs.readFileSync(path.join(root, 'tools', 'advanced-email.js'), 'utf8').includes('fetch('), 'Offline advanced portal must not invoke a mail API');
const tests = JSON.parse(fs.readFileSync(path.join(root, 'tests', 'cases.json'), 'utf8'));
assert.equal(new Set(tests.map(test => test.id)).size, 14);
const snapshot = fs.readFileSync(path.join(root, 'knowledge', '01-Synthetic-Client-Snapshot.md'), 'utf8');
assert.equal([...snapshot.matchAll(/^## Client LAB-\d{3} /gm)].length, 5);
assert.equal([...snapshot.matchAll(/^## Client LAB-\d{3} — Chris Lee$/gm)].length, 2);
assert(!snapshot.includes('LAB-999 —'));
for (const email of snapshot.match(/[\w.-]+@[\w.-]+/g) || []) assert(email.endsWith('.invalid'), `Non-training email: ${email}`);
assert(snapshot.includes('**Health disclosures:** Not supplied.'));
const coverage = fs.readFileSync(path.join(root, 'knowledge', '02-Fictional-Coverage-Guide.md'), 'utf8');
assert.equal([...coverage.matchAll(/^## Product /gm)].length, 4);
assert(coverage.includes('no premiums'));
if (errors.length) { console.error(errors.join('\n')); process.exitCode = 1; }
else console.log(`PASS: ${checkedLinks} local HTML links, JavaScript syntax, 7 core + 4 advanced prompts, 14 core + 10 separate advanced cases, synthetic data, and three-pack separation.`);