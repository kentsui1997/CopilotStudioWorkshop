# Advisor Meeting Prep — Multi-Agent Workshop

**Prepared for a Manulife Copilot Studio workshop | 11 September 2026 | 120 minutes**

Build four separate agents with the **GitHub Copilot harness in Microsoft Copilot Studio**. A Hub coordinates a Client Briefing specialist, a Coverage Guide specialist, and a Follow-up Drafting specialist to produce an advisor meeting-preparation pack.

**All customer profiles, products, rules, and contact addresses are fictional Contoso Assurance training material. Nothing in this kit represents a Manulife product, policy, endorsement, or customer record.**

## Start here

- Open [START-HERE.html](START-HERE.html) in a browser for the offline workshop portal, team-prefix substitution, copy buttons, downloads, and test checklist. No installation or server is needed to use it.
- Participants: follow [01-Participant-Lab.md](01-Participant-Lab.md), or its [Word handout](handouts/Participant-Lab.docx) / [PDF handout](handouts/Participant-Lab.pdf).
- Instructor: use [02-Instructor-Runbook.md](02-Instructor-Runbook.md), [03-Tenant-Preflight.md](03-Tenant-Preflight.md), and [the facilitator slides](handouts/Facilitator-Slides.pptx).
- The [optional workflow lab](04-Optional-Workflow.md) adds a deterministic meeting-time calculation without a connector or business-system write.
- Distribute the participant ZIP from the **sibling delivery folder** produced during the build. The complete facilitator ZIP includes answer keys and source materials; keep it separate from participant distribution.

## What participants learn

1. Create real, separate GitHub-harness agents rather than a single agent pretending to have roles.
2. Configure instructions, attach knowledge, publish specialists, and connect them to a Hub.
3. Preserve relevant task context across delegation without classic topic variables.
4. Validate specialist calls and source use in the activity trace.
5. Test ambiguity, missing data, unsupported financial claims, and no-send boundaries.
6. Optionally add a deterministic workflow tool and distinguish a proposed time from a booked meeting.

## Scope that fits two hours

| Included in core | Deliberately excluded from core |
|---|---|
| Four separate agents; three small uploaded knowledge documents | Live policy administration or CRM access |
| Seventy-minute guided build and tests | SharePoint site/list creation or Dataverse schema setup |
| Internal advisor assistance; unsent messages | Actual insurance recommendations, quotes, underwriting, or claim decisions |
| Observable delegation and grounding | Outlook sending, calendar booking, or audit-record writes |
| Manual agent-creation fallback | A GitHub Actions pipeline, local SDK, custom MCP server, or solution migration |

No external-service connector setup is needed for the core. **Copilot Studio licensing, environment permissions, knowledge upload, specialist publication, and credits are still required.** The optional workflow is also connector-free.

## Two-hour agenda

| Time | Activity | Outcome |
|---|---|---|
| 00–10 | Business scenario, architecture, and FSI boundaries | Understand scope and success criteria |
| 10–25 | Instructor demonstration | See the target and one agent's setup-to-delegation journey |
| 25–35 | Lab 1: create four shells | Four team-prefixed new-harness agents |
| 35–50 | Lab 2: knowledge and instructions | Three grounded specialists; Hub without knowledge |
| 50–65 | Lab 3: publish and connect | Hub with three real connected agents |
| 65–80 | Lab 4: end-to-end pack and trace | Observable multi-agent execution |
| 80–95 | Lab 5: safety tests and refinement | Required acceptance tests and one improvement |
| 95–110 | Optional workflow / catch-up | Deterministic tool or completed core |
| 110–120 | Share back and production discussion | Evidence of completion and next-step design |

## Tonight's hard gate

Run the [tenant preflight](03-Tenant-Preflight.md) with a representative participant account. **Do not rely on a trial-only account:** current documentation says trial users can test but cannot publish, and connected specialists must be published. Credits alone do not resolve every licensing or permission issue. A development/sandbox environment with the required entitlement is appropriate; a production environment is not required.

All four agents must be in the same environment. One maker can own the whole team's set. If using shared facilitator specialists, verify ownership/sharing and actual invocation in that environment before class. Do not share credentials.

## Contents

| Location | Use |
|---|---|
| [01-Participant-Lab.md](01-Participant-Lab.md) | Timed click-by-click core exercise |
| [02-Instructor-Runbook.md](02-Instructor-Runbook.md) | Demo script, answer key, troubleshooting, contingencies |
| [03-Tenant-Preflight.md](03-Tenant-Preflight.md) | Go/no-go checks, account planning, admin checklist |
| [04-Optional-Workflow.md](04-Optional-Workflow.md) | Safe native-workflow extension |
| [05-Facilitator-Slides.md](05-Facilitator-Slides.md) | Editable source for the presentation |
| [06-Test-Checklist.md](06-Test-Checklist.md) | Acceptance criteria and scoring |
| [07-Sources-and-Feature-Notes.md](07-Sources-and-Feature-Notes.md) | Microsoft documentation and explicit verification boundaries |
| [knowledge/01-Synthetic-Client-Snapshot.md](knowledge/01-Synthetic-Client-Snapshot.md) | Source of five synthetic profiles; generated DOCX is for upload |
| [knowledge/02-Fictional-Coverage-Guide.md](knowledge/02-Fictional-Coverage-Guide.md) | Source of four fictional protection concepts |
| [knowledge/03-Communication-Standard.md](knowledge/03-Communication-Standard.md) | Draft-only communication guidance |
| [prompts/00-Builder.txt](prompts/00-Builder.txt) | Four-agent scaffold prompt; full runtime prompts are adjacent |
| [tests/cases.json](tests/cases.json) | Authoring source for the 14-case worksheet, not a Copilot evaluation import schema |

Only upload the three **knowledge DOCX documents** to their assigned specialists. Do not upload the participant guide, instructor runbook, prompts, or answer key as knowledge.

## Verification status

The local build validates document generation, links, source assets, prompt substitutions, slide structure, and the offline portal. Microsoft documentation was checked on 10 September 2026. **No agents have been created, published, or runtime-tested in your tenant by this kit-generation process.** The rehearsal and admin preflight are mandatory before describing the lab as tenant-tested.

The natural-language builder and some adjacent workflow/evaluation features remain marked preview in current Microsoft documentation. Use your organization's approved features and model configuration. Authoring, Preview, and evaluation may consume Copilot Credits.