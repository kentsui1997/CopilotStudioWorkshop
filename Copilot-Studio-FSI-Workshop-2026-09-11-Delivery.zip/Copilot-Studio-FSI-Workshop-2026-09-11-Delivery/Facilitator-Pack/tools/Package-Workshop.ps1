param([string]$SourceRoot = (Split-Path -Parent $PSScriptRoot))
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem
$delivery = $SourceRoot + '-Delivery'
$results = @()
$facilitatorTools = Join-Path $delivery 'Facilitator-Pack\tools'
if (Test-Path -LiteralPath $facilitatorTools) {
    Get-ChildItem -LiteralPath $PSScriptRoot -File | ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $facilitatorTools $_.Name) -Force }
}
foreach ($office in (Get-ChildItem -LiteralPath $SourceRoot -Recurse -File | Where-Object { $_.Extension -in '.docx','.pptx' -and $_.FullName -notlike '*\.build\*' })) {
    $archive = [System.IO.Compression.ZipFile]::OpenRead($office.FullName)
    try {
        foreach ($entry in $archive.Entries) {
            if ($entry.FullName -match '\.(xml|rels)$') {
                $reader = New-Object System.IO.StreamReader($entry.Open())
                try { $xmlText = $reader.ReadToEnd(); $xml = New-Object System.Xml.XmlDocument; $xml.LoadXml($xmlText) } finally { $reader.Dispose() }
            }
        }
        if ($office.Extension -eq '.pptx') {
            $slideCount = @($archive.Entries | Where-Object { $_.FullName -match '^ppt/slides/slide\d+\.xml$' }).Count
            $noteCount = @($archive.Entries | Where-Object { $_.FullName -match '^ppt/notesSlides/notesSlide\d+\.xml$' }).Count
            if ($slideCount -ne 14 -or $noteCount -ne 14) { throw "Expected 14 slides and speaker notes, got $slideCount / $noteCount" }
            $results += "PASS: editable PowerPoint has $slideCount slides and $noteCount speaker-note pages."
        } else {
            if ($null -eq $archive.GetEntry('word/document.xml')) { throw "Missing Word document: $($office.Name)" }
        }
    } finally { $archive.Dispose() }
}
$results += 'PASS: all generated Word and PowerPoint XML parts parsed successfully.'
foreach ($audience in 'Participant','Facilitator') {
    $folder = Join-Path $delivery ($audience + '-Pack')
    $zip = Join-Path $delivery ('Advisor-Meeting-Prep-' + $audience + '-Pack.zip')
    if (Test-Path -LiteralPath $zip) { Remove-Item -LiteralPath $zip }
    $outputArchive = [System.IO.Compression.ZipFile]::Open($zip, [System.IO.Compression.ZipArchiveMode]::Create)
    try {
        foreach ($file in (Get-ChildItem -LiteralPath $folder -Recurse -File)) {
            $entryName = $file.FullName.Substring($folder.Length).TrimStart([char[]]'\/').Replace('\','/')
            [void][System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($outputArchive, $file.FullName, $entryName, [System.IO.Compression.CompressionLevel]::Optimal)
        }
    } finally { $outputArchive.Dispose() }
    $archive = [System.IO.Compression.ZipFile]::OpenRead($zip)
    try {
        if ($null -eq $archive.GetEntry('START-HERE.html')) { throw 'Portal missing from ZIP.' }
        if ($null -eq $archive.GetEntry('handouts/Participant-Lab.pdf')) { throw 'Participant PDF missing from ZIP.' }
        if ($audience -eq 'Participant' -and @($archive.Entries | Where-Object { $_.FullName -match 'Instructor-Runbook|Tenant-Preflight|Facilitator-Slides' }).Count -gt 0) { throw 'Facilitator-only files leaked into participant ZIP.' }
        $results += "PASS: $audience ZIP has $($archive.Entries.Count) entries."
    } finally { $archive.Dispose() }
}
$checksums = Get-ChildItem -LiteralPath $delivery -Filter '*.zip' -File | Get-FileHash -Algorithm SHA256 | ForEach-Object { $_.Hash + '  ' + (Split-Path -Leaf $_.Path) }
[System.IO.File]::WriteAllLines((Join-Path $delivery 'SHA256SUMS.txt'), [string[]]$checksums)
[System.IO.File]::WriteAllLines((Join-Path $delivery 'package-validation.txt'), [string[]]($results + 'Tenant runtime has NOT been tested by this package build.'))
$results
Get-ChildItem -LiteralPath $delivery -Filter '*.zip' -File | Select-Object Name,Length