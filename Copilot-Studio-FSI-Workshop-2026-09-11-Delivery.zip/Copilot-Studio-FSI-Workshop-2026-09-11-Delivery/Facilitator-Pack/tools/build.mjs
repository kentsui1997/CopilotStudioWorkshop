import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { spawnSync } from 'node:child_process';

const tools = path.dirname(fileURLToPath(import.meta.url));
const root = path.dirname(tools);
const delivery = `${root}-Delivery`;
const cache = path.join(root, '.build');
for (const dir of [cache, delivery, path.join(root, 'handouts')]) fs.mkdirSync(dir, { recursive: true });
const read = file => fs.readFileSync(path.join(root, file), 'utf8').replaceAll('\r\n', '\n');
const write = (file, content) => { fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, content); };
const escape = value => String(value).replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;');
const css = read('tools/site.css');
const pandoc = process.env.PANDOC || 'pandoc';
function run(command, args, options = {}) {
  const result = spawnSync(command, args, { cwd: root, encoding: 'utf8', maxBuffer: 12 * 1024 * 1024, windowsHide: true, ...options });
  if (result.error || result.status !== 0) throw new Error(`${command} failed: ${result.error?.message || result.stderr || result.status}`);
  return result.stdout;
}
console.log(run(pandoc, ['--version']).split('\n')[0]);
function markdown(text, flavor = 'gfm') { return run(pandoc, ['--from', flavor, '--to', 'html5', '--wrap', 'none'], { input: text }); }
function htmlLinks(html) {
  return html.replace(/href="([^"#]+)\.md(#[^"]*)?"/g, (match, target, hash = '') => /^https?:/i.test(target) ? match : `href="${target}.html${hash}"`);
}
function page(title, content, home = 'START-HERE.html') {
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escape(title)}</title><style>${css}</style></head><body><div class="doc-toolbar no-print"><a class="button secondary" href="${home}">Workshop portal</a><button onclick="print()">Print / save PDF</button></div><main class="document-wrapper"><article class="document">${content}</article></main></body></html>`;
}
const promptNames = [
  ['00-Builder.txt', 'Builder prompt — four agent shells', 'Paste into Copilot Studio Home / builder chat'],
  ['01-Hub-Instructions.txt', 'Hub — full runtime instructions', 'Paste into Hub → Build → Instructions (replace starter text)'],
  ['02-Client-Briefing-Instructions.txt', 'Client Briefing — full runtime instructions', 'Paste into Client Briefing → Build → Instructions'],
  ['03-Coverage-Guide-Instructions.txt', 'Coverage Guide — full runtime instructions', 'Paste into Coverage Guide → Build → Instructions'],
  ['04-Follow-up-Drafting-Instructions.txt', 'Follow-up Drafting — full runtime instructions', 'Paste into Follow-up Drafting → Build → Instructions'],
  ['05-Workflow-Builder.txt', 'Optional workflow builder', 'Optional: paste into builder chat, not Preview'],
  ['06-Workflow-Agent-Delta.txt', 'Optional workflow agent delta', 'Optional: append to Follow-up Drafting instructions; do not replace them']
];
const prompts = promptNames.map(([file, title, destination]) => ({ file, title, destination, text: read(`prompts/${file}`).trim() }));
const tests = JSON.parse(read('tests/cases.json'));
if (tests.length !== 14 || tests.filter(test => test.required).length !== 8) throw new Error('Expected 14 test cases, eight required.');
const sources = [
  'README.md', '01-Participant-Lab.md', '02-Instructor-Runbook.md', '03-Tenant-Preflight.md',
  '04-Optional-Workflow.md', '06-Test-Checklist.md', '07-Sources-and-Feature-Notes.md',
  'knowledge/01-Synthetic-Client-Snapshot.md', 'knowledge/02-Fictional-Coverage-Guide.md', 'knowledge/03-Communication-Standard.md'
];
for (const source of sources) {
  const text = read(source); const title = text.match(/^# (.+)$/m)?.[1] || source;
  write(path.join(root, source.replace(/\.md$/, '.html')), page(title, htmlLinks(markdown(text)), source.startsWith('knowledge/') ? '../START-HERE.html#knowledge' : 'START-HERE.html'));
}
function wrap(text, width = 88) {
  return text.split('\n').map(line => {
    if (line.length <= width) return line;
    const words = line.split(/\s+/); const lines = []; let current = '';
    for (const word of words) { if (current && current.length + word.length + 1 > width) { lines.push(current); current = word; } else current += `${current ? ' ' : ''}${word}`; }
    if (current) lines.push(current); return lines.join('\n');
  }).join('\n');
}
const appendix = '\n\n# Appendix — Full Copy-and-Paste Prompt Book\n\nReplace every {{TEAM}} with your assigned team key before pasting. The offline portal performs this substitution automatically. Paste builder prompts into Home chat, runtime instructions into Build, and test prompts into Preview.\n\n' + prompts.map(prompt => `## ${prompt.title}\n\n**${prompt.destination}**\n\n~~~text\n${wrap(prompt.text)}\n~~~\n`).join('\n');
const participant = read('01-Participant-Lab.md') + appendix;
const handoutSpecs = [
  ['Participant-Lab', participant],
  ['Instructor-Runbook', read('02-Instructor-Runbook.md')],
  ['Tenant-Preflight', read('03-Tenant-Preflight.md')],
  ['Optional-Workflow', read('04-Optional-Workflow.md')],
  ['Test-Checklist', read('06-Test-Checklist.md')]
];
function linksForHandout(text) {
  return text.replace(/\]\(([^)]+)\)/g, (match, target) => /^(?:https?:|#|mailto:)/i.test(target) ? match : `](../${target})`);
}
for (const [name, text] of handoutSpecs) {
  run(pandoc, ['--from', 'markdown', '--to', 'docx', '--toc', '--toc-depth', '2', '--output', path.join(root, 'handouts', `${name}.docx`)], { input: linksForHandout(text) });
  const html = htmlLinks(markdown(linksForHandout(text), 'markdown'));
  write(path.join(root, 'handouts', `${name}.html`), page(name.replaceAll('-', ' '), html, '../START-HERE.html'));
}
for (const source of sources.filter(file => file.startsWith('knowledge/'))) {
  run(pandoc, ['--from', 'markdown', '--to', 'docx', '--output', path.join(root, source.replace(/\.md$/, '.docx'))], { input: read(source) });
}
const slideSource = read('05-Facilitator-Slides.md');
run(pandoc, ['--from', 'markdown+fenced_divs', '--to', 'pptx', '--slide-level', '2', '--output', path.join(root, 'handouts', 'Facilitator-Slides.pptx')], { input: slideSource });
const slideParts = slideSource.trim().split(/^## /m).filter(Boolean);
if (slideParts.length !== 14) throw new Error(`Expected 14 slides, got ${slideParts.length}`);
const slideHtml = slideParts.map((part, index) => {
  const content = markdown(`## ${part}`, 'markdown+fenced_divs');
  return `<section class="slide${index === 0 ? ' active' : ''}" aria-label="Slide ${index + 1}"><div class="kicker">Copilot Studio workshop · 11 September 2026</div>${content}<div class="smallprint">Fictional Contoso Assurance training content · Not Manulife products, policies, or customer data</div></section>`;
}).join('\n');
const deckScript = `(() => { let current = 0; const slides = [...document.querySelectorAll('.slide')]; function show(index) { current = Math.max(0, Math.min(slides.length - 1, index)); slides.forEach((slide, i) => { slide.classList.toggle('active', i === current); slide.querySelectorAll('.notes').forEach(note => note.classList.remove('show')); }); document.getElementById('counter').textContent = (current + 1) + ' / ' + slides.length; } document.getElementById('prev').onclick = () => show(current - 1); document.getElementById('next').onclick = () => show(current + 1); document.getElementById('notes').onclick = () => slides[current].querySelector('.notes')?.classList.toggle('show'); document.addEventListener('keydown', event => { if (['ArrowRight','PageDown'].includes(event.key)) { event.preventDefault(); show(current + 1); } else if (['ArrowLeft','PageUp'].includes(event.key)) { event.preventDefault(); show(current - 1); } else if (event.key === 'Home') show(0); else if (event.key === 'End') show(slides.length - 1); }); show(0); })();`;
write(path.join(root, '05-Facilitator-Slides.html'), `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Advisor Meeting Prep | Facilitator slides</title><style>${read('tools/slides.css')}</style></head><body>${slideHtml}<div class="deck-toolbar"><a href="START-HERE.html#facilitator">Workshop portal</a><span>Arrow keys / Page Up / Page Down</span><div class="nav-buttons"><button id="notes">Speaker notes</button><button id="prev" aria-label="Previous slide">←</button><span id="counter">1 / 14</span><button id="next" aria-label="Next slide">→</button></div></div><script>${deckScript}</script></body></html>`);
function portal(audience) {
  const facilitator = audience === 'Facilitator';
  const replacements = {
    CSS: css,
    AUDIENCE: audience,
    LAB: htmlLinks(markdown(read('01-Participant-Lab.md'))),
    EXTENSION: htmlLinks(markdown(read('04-Optional-Workflow.md'))),
    FACILITATOR_NAV: facilitator ? '<a href="#facilitator">07 · Facilitator desk</a>' : '',
    FACILITATOR_PANEL: facilitator ? `<section id="facilitator" class="panel" hidden><p class="eyebrow">Facilitator desk</p><h1>Ready for tomorrow.</h1><p>Rehearse with a representative participant account tonight. Local file validation does not establish tenant readiness.</p><div class="notice"><strong>Hard gate:</strong> create → upload → publish specialist → connect → invoke. Keep the finished FSI-DEMO set separate from FSI-LIVE.</div><div class="download-list"><a href="03-Tenant-Preflight.html">Tonight's tenant preflight and go/no-go</a><a href="02-Instructor-Runbook.html">Minute-by-minute instructor runbook + illustrative answer key</a><a href="05-Facilitator-Slides.html">Present the 14-slide browser deck</a><a href="handouts/Facilitator-Slides.pptx">Download editable PowerPoint slides</a><a href="handouts/Facilitator-Slides.pdf">Download slides as PDF</a><a href="handouts/Instructor-Runbook.pdf">Instructor runbook · PDF</a><a href="handouts/Tenant-Preflight.pdf">Tenant preflight · PDF</a><a href="07-Sources-and-Feature-Notes.html">Documentation and verification boundaries</a></div><h2>Demo plan</h2><ol class="steps"><li>Show the completed LAB-001 pack and actual specialist calls.</li><li>Create one Drafting specialist; paste instructions, attach knowledge, publish.</li><li>Connect it to the prepared live Hub.</li><li>Demonstrate the no-send boundary, then hand over at minute 25.</li></ol><p class="muted">Distribute the participant ZIP, not this facilitator edition. A localhost preview link does not work for attendees on other computers.</p></section>` : '',
    DATA: JSON.stringify({ audience, prompts, tests }).replaceAll('<', '\\u003c'),
    JS: read('tools/portal.js')
  };
  return read('tools/portal.html').replace(/@@([A-Z_]+)@@/g, (_, key) => { if (!(key in replacements)) throw new Error(`Unknown template token ${key}`); return replacements[key]; });
}
write(path.join(root, 'START-HERE.html'), portal('Facilitator'));

const edge = [process.env.EDGE, 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe', 'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe'].find(file => file && fs.existsSync(file));
if (!edge) throw new Error('Microsoft Edge was not found for PDF generation.');
const pdfCounts = {};
for (const name of [...handoutSpecs.map(([name]) => name), 'Facilitator-Slides']) {
  const input = name === 'Facilitator-Slides' ? path.join(root, '05-Facilitator-Slides.html') : path.join(root, 'handouts', `${name}.html`);
  const output = path.join(root, 'handouts', `${name}.pdf`);
  // Reuse only when the change affects the portal, not printed document content.
  if (!process.argv.includes('--reuse-pdfs')) {
    run(edge, ['--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check', '--no-pdf-header-footer', `--user-data-dir=${path.join(cache, `edge-${name}`)}`, `--print-to-pdf=${output}`, pathToFileURL(input).href], { timeout: 120000 });
  }
  const pdf = fs.readFileSync(output);
  if (pdf.subarray(0, 5).toString() !== '%PDF-') throw new Error(`Invalid PDF: ${name}`);
  pdfCounts[name] = [...pdf.toString('latin1').matchAll(/\/Type\s*\/Page\b/g)].length;
  if (!pdfCounts[name]) throw new Error(`PDF page count unavailable: ${name}`);
  if (name === 'Facilitator-Slides' && pdfCounts[name] !== 14) throw new Error(`Slides PDF has ${pdfCounts[name]} pages, expected 14.`);
  console.log(`PDF ${name}: ${pdfCounts[name]} pages`);
}

const participantReadme = `# Advisor Meeting Prep — Participant Pack\n\n**Manulife workshop | 11 September 2026 | Fictional Contoso Assurance training only**\n\n1. Extract the entire ZIP.\n2. Open [START-HERE.html](START-HERE.html) in your browser. No installation is required for the pack.\n3. Set your assigned team key and follow the participant lab.\n4. Download the three knowledge DOCX files from the portal and upload one to each assigned specialist.\n5. Use the PDF/Word handouts when preferred. The participant handout contains all seven copy-and-paste prompts in its appendix.\n\nThe portal is offline; Copilot Studio requires internet, an approved environment, credits, and an account that can publish and invoke specialists. Trial-only Preview may not support the full exercise. No real customer data, product terms, or business writes are needed.\n\nThe local test worksheet is not an automated agent evaluation. Current feature documentation and limitations are in [Sources and Feature Notes](07-Sources-and-Feature-Notes.html). This pack is not a Copilot Studio importable solution.\n`;
const core = ['01-Participant-Lab', '04-Optional-Workflow', '06-Test-Checklist', '07-Sources-and-Feature-Notes'];
function copyRelative(source, destination, file) {
  const target = path.join(destination, file); fs.mkdirSync(path.dirname(target), { recursive: true }); fs.copyFileSync(path.join(source, file), target);
}
function listFiles(dir, base = dir) {
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap(entry => entry.isDirectory() ? listFiles(path.join(dir, entry.name), base) : [path.relative(base, path.join(dir, entry.name)).replaceAll('\\', '/')]);
}
for (const audience of ['Participant', 'Facilitator']) {
  const target = path.join(delivery, `${audience}-Pack`); fs.mkdirSync(target, { recursive: true });
  const bases = audience === 'Facilitator' ? [...core, 'README', '02-Instructor-Runbook', '03-Tenant-Preflight', '05-Facilitator-Slides'] : core;
  for (const base of bases) for (const ext of ['md', 'html']) copyRelative(root, target, `${base}.${ext}`);
  for (const folder of ['knowledge', 'prompts', 'tests']) for (const file of listFiles(path.join(root, folder))) copyRelative(root, target, `${folder}/${file}`);
  const handouts = audience === 'Facilitator' ? listFiles(path.join(root, 'handouts')) : listFiles(path.join(root, 'handouts')).filter(file => /^(Participant-Lab|Optional-Workflow|Test-Checklist)\./.test(file));
  for (const file of handouts) copyRelative(root, target, `handouts/${file}`);
  if (audience === 'Facilitator') for (const file of listFiles(tools)) copyRelative(root, target, `tools/${file}`);
  else { write(path.join(target, 'README.md'), participantReadme); write(path.join(target, 'README.html'), page('Participant Pack', markdown(participantReadme))); }
  write(path.join(target, 'START-HERE.html'), portal(audience));
}
const landing = `<div class="eyebrow">Workshop delivery · 11 September 2026</div><h1>Advisor Meeting Prep</h1><p>Four connected Copilot Studio agents. A two-hour workshop with synthetic insurance data, copyable prompts, upload-ready knowledge, and instructor materials.</p><div class="notice success-note"><strong>Use the participant ZIP for distribution.</strong> Extract it and open START-HERE in a browser. Copilot Studio still needs tenant access. This local preview link is only for this computer.</div><div class="grid"><div class="card"><h3>Participant pack</h3><p>Offline lab portal, PDF/Word handouts, three knowledge DOCX files, prompts, and tests.</p><a class="button" href="Advisor-Meeting-Prep-Participant-Pack.zip" download>Download participant ZIP</a><p class="legend"><a href="Participant-Pack/START-HERE.html">Preview participant portal</a></p></div><div class="card"><h3>Facilitator pack</h3><p>Everything above plus runbook, preflight, answer key, 14-slide presentation, and sources.</p><a class="button" href="Advisor-Meeting-Prep-Facilitator-Pack.zip" download>Download facilitator ZIP</a><p class="legend"><a href="Facilitator-Pack/START-HERE.html#facilitator">Open facilitator desk</a></p></div><div class="card"><h3>Check tonight</h3><p>Verify that a representative participant can publish and invoke specialists. Trial-only Preview may not be enough.</p><a class="button secondary" href="Facilitator-Pack/03-Tenant-Preflight.html">Open tenant preflight</a><p class="legend"><a href="Facilitator-Pack/handouts/Facilitator-Slides.pptx">Editable PowerPoint</a></p></div></div><h2>Verification boundary</h2><p>Local files are generated and checked; Copilot Studio agents have not been created or runtime-tested in your tenant by this process. Run the preflight and instructor rehearsal before class.</p><p class="muted">All products, profiles, and standards are fictional Contoso Assurance training content—not Manulife products, policies, or customer records.</p>`;
write(path.join(delivery, 'index.html'), page('Workshop delivery', landing, 'Facilitator-Pack/START-HERE.html'));
const report = { builtAt: new Date().toISOString(), documentationChecked: '2026-09-10', workshopDate: '2026-09-11', agents: 4, knowledgeDocuments: 3, prompts: prompts.length, slides: slideParts.length, tests: tests.length, requiredTests: 8, pdfPages: pdfCounts, tenantRuntime: 'NOT TESTED — facilitator preflight and rehearsal required', browserValidation: 'Run separately after generation' };
write(path.join(delivery, 'build-report.json'), JSON.stringify(report, null, 2));
console.log(`Generated source pack and delivery folders: ${delivery}`);
console.log('Next: validate links, validate Office packages, create ZIP archives, and check the portal in a browser.');